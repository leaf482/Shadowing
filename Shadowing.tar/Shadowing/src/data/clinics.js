export const MAP_CENTER = {
  lat: 47.2446,
  lng: -122.4376
};

export const DEFAULT_ZOOM = 12;
